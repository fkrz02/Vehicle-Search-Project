var allVehicles = [];

fetch('vehicles.json')
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        allVehicles = data;
        console.log("Data loaded successfully");
        
        createDropdown("fuel");
        createDropdown("colour");
    })


    .catch(function(e) {
        console.error("Error loading vehicles", e);
    });



function createDropdown(fieldID) {
    var values = allVehicles.map(function(car) {
        return car[fieldID];
    });

    var uniqueValues = new Set(values);
    var dropdown = document.getElementById(fieldID + 'Select');
    
    if (dropdown) {
        uniqueValues.forEach(function(item) {
            var option = document.createElement('option');
            option.value = item.toLowerCase();
            option.innerText = item;
            dropdown.appendChild(option);
        });
    }
}


var resultsDisplay = document.getElementById('resultsContainer');



document.getElementById('vehicleSearchForm').addEventListener('submit', function(e) {
    e.preventDefault(); 
    


    var nameInput = document.getElementById('nameSearch').value.toLowerCase();
    var fuelInput = document.getElementById('fuelSelect').value.toLowerCase();
    var colourInput = document.getElementById('colourSelect').value.toLowerCase();
    var yearInput = document.getElementById('yearSearch').value;

    var filtered = allVehicles.filter(function(car) {


        var matchesName = false;
        if (car.make.toLowerCase().includes(nameInput)) {
            matchesName = true;
        } else if (car.model.toLowerCase().includes(nameInput)) {
            matchesName = true;
        }

        var matchesFuel = (fuelInput === "" || car.fuel.toLowerCase() === fuelInput);

        var matchesColour = (colourInput === "" || car.colour.toLowerCase() === colourInput);


        var matchesYear = (yearInput === "" || car.year.toString() === yearInput);


        if (matchesName && matchesFuel && matchesColour && matchesYear) {
            return true;
        } else {
            return false;
        }
    });

    displayVehicles(filtered);
});


function displayVehicles(list) {
    resultsDisplay.innerHTML = ""; 

    if (list.length === 0) {
        resultsDisplay.innerHTML = "<p>No vehicles found </p>";
        return;
    }

    list.forEach(function(car) {
        var card = document.createElement('div');
        card.className = "vehicle-card";
        card.innerHTML = "<h3>" + car.make + " " + car.model + "</h3>" +
                         "<p><strong>Year:</strong> " + car.year + "</p>" +
                         "<p><strong>Fuel:</strong> " + car.fuel + "</p>" +
                         "<p><strong>Colour:</strong> " + car.colour + "</p>";
        resultsDisplay.appendChild(card);
    });
    
}